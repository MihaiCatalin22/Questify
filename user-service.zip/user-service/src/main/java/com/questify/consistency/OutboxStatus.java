package com.questify.consistency;

public enum OutboxStatus {
    NEW,
    SENT,
    FAILED
}
